import re

def analyze_structure(raw_text: str) -> dict:
    """
    Analyzes lyrics structure by identifying explicit markers ([Verse], [Chorus], etc.)
    or falling back to structural line/paragraph breakdown.
    """
    if not raw_text or not raw_text.strip():
        return {
            "has_explicit_markers": False,
            "sections": [],
            "total_sections": 0,
            "lines_count": 0,
            "paragraphs_count": 0,
            "avg_words_per_line": 0.0
        }

    lines = [line.strip() for line in raw_text.splitlines() if line.strip()]
    paragraphs = [p.strip() for p in raw_text.split('\n\n') if p.strip()]

    # Check for brackets like [Verse 1], [Chorus], (Intro), etc.
    section_matches = re.findall(r'\[(.*?)\]|\((Intro|Verse|Chorus|Bridge|Outro|Hook|Pre-Chorus).*?\)', raw_text, re.IGNORECASE)
    
    sections = []
    for match in section_matches:
        marker = match[0] if match[0] else match[1]
        if marker.strip():
            sections.append(marker.strip())

    has_explicit = len(sections) > 0

    # Calculate avg words per line
    total_words_in_lines = sum(len(line.split()) for line in lines)
    avg_words_per_line = round(total_words_in_lines / len(lines), 1) if lines else 0.0

    return {
        "has_explicit_markers": has_explicit,
        "sections": sections if has_explicit else [],
        "total_sections": len(sections),
        "lines_count": len(lines),
        "paragraphs_count": len(paragraphs),
        "avg_words_per_line": avg_words_per_line
    }
