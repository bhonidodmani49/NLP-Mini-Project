from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from textblob import TextBlob

_vader_analyzer = None

def get_vader_analyzer():
    global _vader_analyzer
    if _vader_analyzer is None:
        try:
            _vader_analyzer = SentimentIntensityAnalyzer()
        except Exception:
            _vader_analyzer = None
    return _vader_analyzer

def analyze_sentiment(raw_text: str) -> dict:
    """
    Analyzes sentiment of lyrics using VADER and TextBlob.
    Calculates positive, negative, neutral, compound scores, polarity, subjectivity, and dynamic commentary.
    """
    if not raw_text or not raw_text.strip():
        return {
            "classification": "Neutral",
            "emoji": "😐",
            "compound_score": 0.0,
            "positive_score": 0.0,
            "negative_score": 0.0,
            "neutral_score": 1.0,
            "polarity": 0.0,
            "subjectivity": 0.0,
            "explanation": "No text provided for sentiment analysis."
        }

    # VADER Analysis
    vader = get_vader_analyzer()
    if vader:
        try:
            vader_scores = vader.polarity_scores(raw_text)
            pos = vader_scores.get('pos', 0.0)
            neg = vader_scores.get('neg', 0.0)
            neu = vader_scores.get('neu', 0.0)
            compound = vader_scores.get('compound', 0.0)
        except Exception:
            pos, neg, neu, compound = 0.0, 0.0, 1.0, 0.0
    else:
        pos, neg, neu, compound = 0.0, 0.0, 1.0, 0.0


    # TextBlob Polarity & Subjectivity
    try:
        blob = TextBlob(raw_text)
        tb_polarity = round(blob.sentiment.polarity, 3)
        tb_subjectivity = round(blob.sentiment.subjectivity, 3)
    except Exception:
        tb_polarity = 0.0
        tb_subjectivity = 0.0

    # Classification
    if compound >= 0.05:
        classification = "Positive"
        emoji = "😊"
        if compound >= 0.6:
            explanation = "The song lyrics express an overwhelmingly positive, uplifting, and joyful emotional tone."
        else:
            explanation = "The lyrics carry a moderately positive tone with hopeful and optimistic themes."
    elif compound <= -0.05:
        classification = "Negative"
        emoji = "😔"
        if compound <= -0.6:
            explanation = "The song lyrics carry a deeply intense negative emotional tone, reflecting grief, anger, or despair."
        else:
            explanation = "The lyrics express a somewhat somber, melancholy, or reflective tone."
    else:
        classification = "Neutral"
        emoji = "😐"
        explanation = "The lyrics maintain a balanced or neutral sentiment without strong positive or negative emotional polarity."

    return {
        "classification": classification,
        "emoji": emoji,
        "compound_score": round(compound, 3),
        "positive_score": round(pos * 100, 1),
        "negative_score": round(neg * 100, 1),
        "neutral_score": round(neu * 100, 1),
        "polarity": tb_polarity,
        "subjectivity": tb_subjectivity,
        "explanation": explanation
    }
