def analyze_word_length(preprocessed_data: dict) -> dict:
    """
    Categorizes word tokens into length buckets (1-3, 4-6, 7-9, 10+ letters).
    """
    tokens = preprocessed_data.get("tokens", [])
    
    buckets = {
        "1-3 letters": 0,
        "4-6 letters": 0,
        "7-9 letters": 0,
        "10+ letters": 0
    }

    for token in tokens:
        length = len(token)
        if 1 <= length <= 3:
            buckets["1-3 letters"] += 1
        elif 4 <= length <= 6:
            buckets["4-6 letters"] += 1
        elif 7 <= length <= 9:
            buckets["7-9 letters"] += 1
        elif length >= 10:
            buckets["10+ letters"] += 1

    total = sum(buckets.values())
    percentages = {}
    if total > 0:
        for b, count in buckets.items():
            percentages[b] = round((count / total) * 100, 1)
    else:
        percentages = {b: 0.0 for b in buckets}

    return {
        "counts": buckets,
        "percentages": percentages,
        "labels": list(buckets.keys()),
        "values": list(buckets.values())
    }
