import re
import string
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer, PorterStemmer

lemmatizer = WordNetLemmatizer()
stemmer = PorterStemmer()

# Custom music stop words to exclude if needed, standard NLTK stopwords set
try:
    STOP_WORDS = set(stopwords.words('english'))
except Exception:
    STOP_WORDS = {"a", "an", "the", "in", "on", "of", "and", "or", "is", "are", "was", "were", "to", "for", "with", "it", "this", "that"}

# Add common section header words to stopwords filter for pure content analysis if desired
SECTION_HEADERS = {'intro', 'verse', 'chorus', 'bridge', 'outro', 'hook', 'pre-chorus', 'prechorus'}

def preprocess_lyrics(raw_text: str) -> dict:
    """
    Executes full NLP preprocessing pipeline on song lyrics.
    Returns dictionary with original text, cleaned text, tokens, lemmatized tokens, and stems.
    """
    if not raw_text or not raw_text.strip():
        return {
            "original_text": "",
            "cleaned_text": "",
            "tokens": [],
            "content_tokens": [],
            "lemmatized_tokens": [],
            "stemmed_tokens": [],
            "removed_stopwords": []
        }

    original_text = raw_text.strip()
    
    # 1. Lowercase
    lowercased = original_text.lower()
    
    # Remove section markers like [Verse 1], [Chorus], etc. for token analysis
    text_no_headers = re.sub(r'\[.*?\]', ' ', lowercased)

    # 2 & 3. Remove punctuation and special characters
    # Keep alpha-numeric and whitespace
    cleaned_chars = []
    for char in text_no_headers:
        if char.isalnum() or char.isspace():
            cleaned_chars.append(char)
        else:
            cleaned_chars.append(' ')
    text_clean = "".join(cleaned_chars)
    
    # Normalize extra whitespace
    cleaned_text = re.sub(r'\s+', ' ', text_clean).strip()

    # 4. Tokenization
    try:
        raw_tokens = word_tokenize(cleaned_text)
    except Exception:
        raw_tokens = cleaned_text.split()

    tokens = [t for t in raw_tokens if t.isalnum()]

    # 5. Stopword filtering
    content_tokens = []
    removed_stopwords = []
    for token in tokens:
        if token in STOP_WORDS or token in SECTION_HEADERS:
            removed_stopwords.append(token)
        elif len(token) > 1 or token in {'i', 'a'}:
            content_tokens.append(token)

    # 7. Lemmatization
    lemmatized_tokens = []
    for token in content_tokens:
        try:
            lemmatized_tokens.append(lemmatizer.lemmatize(token))
        except Exception:
            lemmatized_tokens.append(token)

    # 8. Stemming
    stemmed_tokens = [stemmer.stem(token) for token in content_tokens]

    return {
        "original_text": original_text,
        "cleaned_text": cleaned_text,
        "tokens": tokens,
        "content_tokens": content_tokens,
        "lemmatized_tokens": lemmatized_tokens,
        "stemmed_tokens": stemmed_tokens,
        "removed_stopwords": list(set(removed_stopwords))
    }
