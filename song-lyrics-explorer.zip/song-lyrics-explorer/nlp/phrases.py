from collections import Counter
import nltk
from nltk.util import ngrams

def extract_phrases(preprocessed_data: dict) -> dict:
    """
    Extracts top Bigram (2-word) and Trigram (3-word) phrases from preprocessed tokens.
    """
    # Use content tokens (without stopwords) for meaningful phrase extraction,
    # as well as cleaned text tokens for natural phrases
    content_tokens = preprocessed_data.get("content_tokens", [])
    raw_tokens = preprocessed_data.get("tokens", [])

    # We generate n-grams using content tokens for cleaner phrase insights
    target_tokens = content_tokens if len(content_tokens) >= 2 else raw_tokens

    # Bigrams
    bigram_counts = Counter(ngrams(target_tokens, 2))
    top_bigrams = [
        {"phrase": " ".join(bg), "frequency": count}
        for bg, count in bigram_counts.most_common(10)
    ]

    # Trigrams
    trigram_counts = Counter(ngrams(target_tokens, 3))
    top_trigrams = [
        {"phrase": " ".join(tg), "frequency": count}
        for tg, count in trigram_counts.most_common(10)
    ]

    return {
        "bigrams": top_bigrams,
        "trigrams": top_trigrams
    }
