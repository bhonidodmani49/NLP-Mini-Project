from collections import defaultdict
import nltk

_cmu_dict = None

def get_cmu_dict():
    """Lazily loads CMU dictionary with automatic NLTK fallback download."""
    global _cmu_dict
    if _cmu_dict is None:
        try:
            _cmu_dict = nltk.corpus.cmudict.dict()
        except Exception:
            try:
                nltk.download('cmudict', quiet=True)
                _cmu_dict = nltk.corpus.cmudict.dict()
            except Exception:
                _cmu_dict = {}
    return _cmu_dict

def get_rhyme_tail(pronunciation):
    """
    Extracts the phonetic rhyme tail: from the last stressed vowel (or last vowel) to the end of the phone list.
    """
    vowel_indices = [i for i, phone in enumerate(pronunciation) if phone[-1].isdigit()]
    if vowel_indices:
        last_vowel_idx = vowel_indices[-1]
        tail = []
        for p in pronunciation[last_vowel_idx:]:
            phone_no_stress = ''.join([c for c in p if not c.isdigit()])
            tail.append(phone_no_stress)
        return "-".join(tail)
    return None

def detect_rhymes(preprocessed_data: dict) -> dict:
    """
    Detects possible rhyming word groups from unique lyrics tokens using the CMU Pronouncing Dictionary.
    """
    cmu_dict = get_cmu_dict()
    tokens = preprocessed_data.get("tokens", [])
    unique_words = sorted(list(set(w.lower() for w in tokens if len(w) >= 2)))

    rhyme_map = defaultdict(set)

    for word in unique_words:
        if word in cmu_dict:
            pronunciations = cmu_dict[word]
            for pron in pronunciations:
                tail = get_rhyme_tail(pron)
                if tail:
                    rhyme_map[tail].add(word)

    # Filter rhyme groups to those with at least 2 distinct words
    groups = []
    group_id = 1

    sorted_tails = sorted(rhyme_map.items(), key=lambda x: len(x[1]), reverse=True)

    for tail, word_set in sorted_tails:
        if len(word_set) >= 2:
            word_list = sorted(list(word_set))
            groups.append({
                "group_name": f"Group {group_id}",
                "phonetic_tail": tail,
                "words": word_list,
                "count": len(word_list)
            })
            group_id += 1
            if group_id > 12:
                break

    return {
        "rhyme_groups": groups,
        "total_groups_count": len(groups),
        "label": "Possible Rhymes",
        "explanation": "Rhyme groups detected using NLTK CMU Pronouncing Dictionary phonetic endings."
    }

