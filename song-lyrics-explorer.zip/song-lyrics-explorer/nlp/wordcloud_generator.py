import os
import uuid
import io
import base64
import matplotlib
matplotlib.use('Agg') # Non-interactive backend for server environments
import matplotlib.pyplot as plt
from wordcloud import WordCloud

def generate_wordcloud(preprocessed_data: dict, output_dir: str) -> dict:
    """
    Generates a dynamic WordCloud from preprocessed content tokens/lemmas.
    Saves PNG image to static directory and returns image file metadata and Base64 encoding.
    """
    lemmatized_tokens = preprocessed_data.get("lemmatized_tokens", [])
    text = " ".join(lemmatized_tokens)

    if not text.strip():
        text = "lyrics music rhythm song melody harmony vocal audio baseline sound beats"

    os.makedirs(output_dir, exist_ok=True)

    filename = f"wordcloud_{uuid.uuid4().hex[:10]}.png"
    filepath = os.path.join(output_dir, filename)

    # Custom styling with dark background and music aesthetic color palette
    wc = WordCloud(
        width=1000,
        height=550,
        background_color='#0F172A', # Dark slate matching UI
        colormap='plasma',         # Purple, magenta, yellow vibrant accents
        max_words=100,
        contour_width=1,
        contour_color='#8B5CF6',
        prefer_horizontal=0.8,
        min_font_size=10
    )

    wc.generate(text)

    # Save PNG file to disk
    wc.to_file(filepath)

    # Generate Base64 string for direct frontend embedding without caching glitches
    img_buffer = io.BytesIO()
    wc.to_image().save(img_buffer, format='PNG')
    img_buffer.seek(0)
    base64_img = base64.b64encode(img_buffer.getvalue()).decode('utf-8')

    return {
        "filename": filename,
        "relative_path": f"generated/wordclouds/{filename}",
        "base64": f"data:image/png;base64,{base64_img}"
    }
