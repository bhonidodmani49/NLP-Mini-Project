# NLP Package Initialization for Song Lyrics Explorer
