import nltk
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

REQUIRED_RESOURCES = [
    ('tokenizers/punkt', 'punkt'),
    ('tokenizers/punkt_tab', 'punkt_tab'),
    ('corpora/stopwords', 'stopwords'),
    ('corpora/wordnet', 'wordnet'),
    ('corpora/omw-1.4', 'omw-1.4'),
    ('sentiment/vader_lexicon', 'vader_lexicon'),
    ('taggers/averaged_perceptron_tagger', 'averaged_perceptron_tagger'),
    ('taggers/averaged_perceptron_tagger_eng', 'averaged_perceptron_tagger_eng'),
    ('corpora/cmudict', 'cmudict'),
]

def ensure_nltk_resources():
    """Downloads all necessary NLTK datasets gracefully if missing."""
    for resource_path, download_name in REQUIRED_RESOURCES:
        try:
            nltk.data.find(resource_path)
            logger.info(f"NLTK resource '{download_name}' is already available.")
        except LookupError:
            logger.info(f"Downloading missing NLTK resource '{download_name}'...")
            try:
                nltk.download(download_name, quiet=True)
            except Exception as e:
                logger.warning(f"Could not download '{download_name}': {e}")

if __name__ == '__main__':
    ensure_nltk_resources()
