from collections import Counter
import nltk
from nltk import pos_tag

# POS tag categories mapping
POS_MAPPING = {
    'NN': 'Nouns', 'NNS': 'Nouns', 'NNP': 'Nouns', 'NNPS': 'Nouns',
    'VB': 'Verbs', 'VBD': 'Verbs', 'VBG': 'Verbs', 'VBN': 'Verbs', 'VBP': 'Verbs', 'VBZ': 'Verbs',
    'JJ': 'Adjectives', 'JJR': 'Adjectives', 'JJS': 'Adjectives',
    'RB': 'Adverbs', 'RBR': 'Adverbs', 'RBS': 'Adverbs', 'WRB': 'Adverbs',
    'PRP': 'Pronouns', 'PRP$': 'Pronouns', 'WP': 'Pronouns', 'WP$': 'Pronouns'
}

def analyze_frequency(preprocessed_data: dict, total_words: int) -> dict:
    """
    Analyzes word frequencies, repeated words, and POS distributions.
    """
    lemmatized_tokens = preprocessed_data.get("lemmatized_tokens", [])
    raw_tokens = preprocessed_data.get("tokens", [])
    
    if not lemmatized_tokens:
        return {
            "top_10": [],
            "top_20": [],
            "top_30": [],
            "most_repeated_word": None,
            "repeated_words": [],
            "pos_distribution": {
                "Nouns": 0, "Verbs": 0, "Adjectives": 0, "Adverbs": 0, "Pronouns": 0, "Other": 0
            },
            "pos_percentages": {
                "Nouns": 0.0, "Verbs": 0.0, "Adjectives": 0.0, "Adverbs": 0.0, "Pronouns": 0.0, "Other": 0.0
            }
        }

    # Word counts on content/lemmatized tokens
    counts = Counter(lemmatized_tokens)
    
    top_30 = [{"word": word, "frequency": count} for word, count in counts.most_common(30)]
    top_10 = top_30[:10]
    top_20 = top_30[:20]

    # Repeated words analysis with percentage of total words
    repeated = []
    total = total_words if total_words > 0 else len(lemmatized_tokens)
    
    for word, count in counts.most_common(15):
        if count >= 2:
            pct = round((count / total) * 100, 2)
            repeated.append({
                "word": word,
                "frequency": count,
                "percentage": pct
            })

    most_repeated = repeated[0] if repeated else (top_10[0] if top_10 else None)

    # POS Analysis
    pos_counts = {
        "Nouns": 0, "Verbs": 0, "Adjectives": 0, "Adverbs": 0, "Pronouns": 0, "Other": 0
    }
    
    try:
        tagged_words = pos_tag(raw_tokens)
    except Exception:
        try:
            nltk.download('averaged_perceptron_tagger', quiet=True)
            nltk.download('averaged_perceptron_tagger_eng', quiet=True)
            tagged_words = pos_tag(raw_tokens)
        except Exception:
            tagged_words = []

    for word, tag in tagged_words:
        category = POS_MAPPING.get(tag, 'Other')
        pos_counts[category] += 1


    total_pos = sum(pos_counts.values())
    pos_percentages = {}
    if total_pos > 0:
        for cat, count in pos_counts.items():
            pos_percentages[cat] = round((count / total_pos) * 100, 2)
    else:
        pos_percentages = {cat: 0.0 for cat in pos_counts}

    return {
        "top_10": top_10,
        "top_20": top_20,
        "top_30": top_30,
        "most_repeated_word": most_repeated,
        "repeated_words": repeated,
        "pos_counts": pos_counts,
        "pos_percentages": pos_percentages
    }
