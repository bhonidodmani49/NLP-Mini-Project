import re
import nltk
from nltk.tokenize import sent_tokenize

def calculate_statistics(raw_text: str, preprocessed_data: dict) -> dict:
    """
    Calculates detailed NLP text metrics and vocabulary statistics.
    """
    if not raw_text or not raw_text.strip():
        return {
            "total_words": 0,
            "unique_words": 0,
            "total_lines": 0,
            "total_sentences": 0,
            "avg_word_length": 0.0,
            "vocabulary_richness": 0.0,
            "total_characters": 0,
            "character_count_no_spaces": 0,
            "total_paragraphs": 0,
            "unique_tokens": 0
        }

    # Lines & Paragraphs
    lines = [line.strip() for line in raw_text.splitlines() if line.strip()]
    paragraphs = [p.strip() for p in raw_text.split('\n\n') if p.strip()]

    # Sentences
    try:
        sentences = sent_tokenize(raw_text)
    except Exception:
        # Fallback split by sentence punctuation or line breaks
        sentences = [s.strip() for s in re.split(r'[.!?]+', raw_text) if s.strip()]

    tokens = preprocessed_data.get("tokens", [])
    lemmatized = preprocessed_data.get("lemmatized_tokens", [])
    
    total_words = len(tokens)
    unique_words_set = set(tokens)
    unique_words = len(unique_words_set)

    unique_lemmas = len(set(lemmatized))

    # Average word length
    if total_words > 0:
        total_char_len = sum(len(word) for word in tokens)
        avg_word_length = round(total_char_len / total_words, 2)
    else:
        avg_word_length = 0.0

    # Vocabulary Richness: Type-Token Ratio (TTR) = (Unique Words / Total Words) * 100
    if total_words > 0:
        vocabulary_richness = round((unique_words / total_words) * 100, 2)
    else:
        vocabulary_richness = 0.0

    total_characters = len(raw_text)
    character_count_no_spaces = len(re.sub(r'\s+', '', raw_text))

    return {
        "total_words": total_words,
        "unique_words": unique_words,
        "total_lines": len(lines),
        "total_sentences": max(len(sentences), len(lines)),
        "avg_word_length": avg_word_length,
        "vocabulary_richness": vocabulary_richness, # percentage
        "total_characters": total_characters,
        "character_count_no_spaces": character_count_no_spaces,
        "total_paragraphs": len(paragraphs),
        "unique_tokens": unique_lemmas
    }
