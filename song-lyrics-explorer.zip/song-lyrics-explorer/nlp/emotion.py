# Lexicon dictionary for music lyric emotion detection
EMOTION_LEXICON = {
    "Joy": {
        "words": {
            "happy", "joy", "smile", "dance", "dancing", "bright", "sun", "sunshine", "light", 
            "laugh", "celebrate", "glory", "gold", "golden", "cheer", "blessed", "alive",
            "shining", "glow", "freedom", "free", "harmony", "peace", "sweet", "sweetheart",
            "spark", "whole", "uplifted", "radiant", "paradise", "bliss", "rejoice", "magic"
        },
        "emoji": "😊"
    },
    "Love": {
        "words": {
            "love", "heart", "hold", "kiss", "forever", "embrace", "baby", "darling",
            "beloved", "passion", "desire", "touch", "together", "soul", "soulmate", 
            "devotion", "sweetheart", "adore", "cherish", "cuddle", "tender", "warmth",
            "mine", "yours", "bound", "lover", "romance", "affection", "flame"
        },
        "emoji": "❤️"
    },
    "Sadness": {
        "words": {
            "sad", "cry", "crying", "tears", "lonely", "alone", "broken", "pain", "dark",
            "darkness", "grief", "sorrow", "bleeding", "cold", "miss", "lost", "empty",
            "hurt", "goodbye", "fade", "fading", "fall", "falling", "heavy", "shatter",
            "heartbreak", "mourn", "blue", "silence", "shadow", "shadows", "regret"
        },
        "emoji": "😢"
    },
    "Anger": {
        "words": {
            "anger", "angry", "hate", "fight", "fighting", "rage", "mad", "fire",
            "burn", "burning", "enemy", "destroy", "kill", "scream", "war", "blood",
            "rebel", "fury", "vengeance", "strike", "smash", "bitter", "furious", "curse"
        },
        "emoji": "😠"
    },
    "Fear": {
        "words": {
            "fear", "scared", "afraid", "dark", "night", "run", "running", "hide",
            "ghost", "danger", "terror", "dread", "panic", "shaking", "tremble",
            "monster", "trap", "trapped", "escape", "warning", "chasing", "shadow"
        },
        "emoji": "😨"
    },
    "Surprise": {
        "words": {
            "surprise", "wonder", "wonderful", "shock", "amazed", "dream", "dreams",
            "sudden", "unexpected", "astonished", "miracle", "spark", "magic", "wild",
            "unbelievable", "mystery", "secret", "discover", "unfold"
        },
        "emoji": "😲"
    },
    "Trust": {
        "words": {
            "trust", "faith", "believe", "guide", "guiding", "true", "truth", "promise",
            "friend", "loyal", "protect", "shelter", "hope", "safe", "stand", "anchor",
            "home", "reliable", "forever", "honest", "sure"
        },
        "emoji": "🤝"
    }
}

def analyze_emotions(preprocessed_data: dict) -> dict:
    """
    Detects emotion breakdown using lexicon-based matching on tokens.
    Calculates raw scores, percentages, and identifies dominant emotion.
    """
    tokens = preprocessed_data.get("tokens", [])
    lemmatized = preprocessed_data.get("lemmatized_tokens", [])
    
    # Combine tokens and lemmatized tokens for broader lexicon matching
    all_words = set(tokens + lemmatized)

    scores = {emotion: 0 for emotion in EMOTION_LEXICON}

    # Count occurrences
    for word in tokens + lemmatized:
        word_lower = word.lower()
        for emotion, data in EMOTION_LEXICON.items():
            if word_lower in data["words"]:
                scores[emotion] += 1

    total_hits = sum(scores.values())

    emotion_percentages = {}
    if total_hits > 0:
        for emotion, score in scores.items():
            emotion_percentages[emotion] = round((score / total_hits) * 100, 1)
    else:
        # Equal distribution or zero fallback
        emotion_percentages = {emotion: 0.0 for emotion in EMOTION_LEXICON}

    # Determine dominant emotion
    sorted_emotions = sorted(scores.items(), key=lambda item: item[1], reverse=True)
    dominant_name, dominant_score = sorted_emotions[0]

    if dominant_score == 0:
        dominant_emotion = "Joy"
        dominant_emoji = "😊"
        dominant_percentage = 0.0
    else:
        dominant_emotion = dominant_name
        dominant_emoji = EMOTION_LEXICON[dominant_name]["emoji"]
        dominant_percentage = emotion_percentages[dominant_name]

    return {
        "dominant_emotion": dominant_emotion,
        "dominant_emoji": dominant_emoji,
        "dominant_score": dominant_score,
        "dominant_percentage": dominant_percentage,
        "scores": scores,
        "percentages": emotion_percentages,
        "disclaimer": "This is an NLP lexicon-based estimation rather than a perfect human interpretation."
    }
