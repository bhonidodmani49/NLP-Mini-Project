/* ==========================================================================
   SONG LYRICS EXPLORER - MAIN JS UTILITIES
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
    console.log("🎵 Song Lyrics Explorer NLP Application Loaded");
});

/**
 * Displays user-friendly alert message in form alert box.
 */
function showAlert(message, type = 'danger') {
    const alertBox = document.getElementById('alertBox');
    if (alertBox) {
        alertBox.className = `alert-box alert-${type}`;
        alertBox.innerHTML = `<i class="fa-solid fa-circle-exclamation"></i> ${message}`;
        alertBox.classList.remove('hidden');
        alertBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
}

/**
 * Clears form alert box.
 */
function clearAlert() {
    const alertBox = document.getElementById('alertBox');
    if (alertBox) {
        alertBox.className = 'alert-box hidden';
        alertBox.innerHTML = '';
    }
}
