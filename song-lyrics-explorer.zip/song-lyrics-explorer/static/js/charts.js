/* ==========================================================================
   SONG LYRICS EXPLORER - CHART.JS VISUALIZER MODULE
   ========================================================================== */

let chartInstances = {};

/**
 * Destroys existing chart instance if canvas is re-rendered.
 */
function destroyChart(chartId) {
    if (chartInstances[chartId]) {
        chartInstances[chartId].destroy();
        delete chartInstances[chartId];
    }
}

/**
 * Render Top Word Frequency Bar Chart
 */
function renderWordFreqChart(canvasId, labels, dataValues) {
    destroyChart(canvasId);
    const ctx = document.getElementById(canvasId).getContext('2d');

    chartInstances[canvasId] = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Frequency Count',
                data: dataValues,
                backgroundColor: 'rgba(139, 92, 246, 0.7)',
                borderColor: '#8B5CF6',
                borderWidth: 1.5,
                borderRadius: 6,
                hoverBackgroundColor: 'rgba(167, 139, 250, 0.9)'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: { backgroundColor: '#1E293B', titleColor: '#FFF', bodyColor: '#A78BFA' }
            },
            scales: {
                x: { ticks: { color: '#94A3B8' }, grid: { color: 'rgba(255, 255, 255, 0.05)' } },
                y: { ticks: { color: '#94A3B8', precision: 0 }, grid: { color: 'rgba(255, 255, 255, 0.05)' }, beginAtZero: true }
            }
        }
    });
}

/**
 * Render Sentiment Doughnut Chart
 */
function renderSentimentChart(canvasId, pos, neg, neu) {
    destroyChart(canvasId);
    const ctx = document.getElementById(canvasId).getContext('2d');

    chartInstances[canvasId] = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Positive %', 'Negative %', 'Neutral %'],
            datasets: [{
                data: [pos, neg, neu],
                backgroundColor: [
                    '#10B981', // Positive Green
                    '#EF4444', // Negative Red
                    '#64748B'  // Neutral Grey
                ],
                borderWidth: 2,
                borderColor: '#151D30'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom', labels: { color: '#F1F5F9', font: { family: 'Inter' } } }
            },
            cutout: '70%'
        }
    });
}

/**
 * Render Emotion Bar Chart
 */
function renderEmotionChart(canvasId, labels, dataValues) {
    destroyChart(canvasId);
    const ctx = document.getElementById(canvasId).getContext('2d');

    chartInstances[canvasId] = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Emotion Score',
                data: dataValues,
                backgroundColor: [
                    '#F59E0B', // Joy
                    '#EC4899', // Love
                    '#3B82F6', // Sadness
                    '#EF4444', // Anger
                    '#8B5CF6', // Fear
                    '#06B6D4', // Surprise
                    '#10B981'  // Trust
                ],
                borderRadius: 6
            }]
        },
        options: {
            indexAxis: 'y', // Horizontal bars
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: { backgroundColor: '#1E293B' }
            },
            scales: {
                x: { ticks: { color: '#94A3B8', precision: 0 }, grid: { color: 'rgba(255, 255, 255, 0.05)' }, beginAtZero: true },
                y: { ticks: { color: '#F1F5F9' }, grid: { display: false } }
            }
        }
    });
}

/**
 * Render N-Gram Phrases Bar Chart
 */
function renderPhrasesChart(canvasId, labels, dataValues) {
    destroyChart(canvasId);
    const ctx = document.getElementById(canvasId).getContext('2d');

    chartInstances[canvasId] = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Occurrences',
                data: dataValues,
                backgroundColor: 'rgba(236, 72, 153, 0.7)',
                borderColor: '#EC4899',
                borderWidth: 1.5,
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { ticks: { color: '#94A3B8' }, grid: { color: 'rgba(255, 255, 255, 0.05)' } },
                y: { ticks: { color: '#94A3B8', precision: 0 }, grid: { color: 'rgba(255, 255, 255, 0.05)' }, beginAtZero: true }
            }
        }
    });
}

/**
 * Render POS Tagging Distribution Pie/Doughnut Chart
 */
function renderPosChart(canvasId, posObj) {
    destroyChart(canvasId);
    const ctx = document.getElementById(canvasId).getContext('2d');

    const labels = Object.keys(posObj);
    const values = Object.values(posObj);

    chartInstances[canvasId] = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{
                data: values,
                backgroundColor: ['#8B5CF6', '#3B82F6', '#EC4899', '#06B6D4', '#F59E0B', '#64748B'],
                borderColor: '#151D30',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'right', labels: { color: '#F1F5F9' } }
            }
        }
    });
}

/**
 * Render Word Length Distribution Bar Chart
 */
function renderWordLengthChart(canvasId, labels, dataValues) {
    destroyChart(canvasId);
    const ctx = document.getElementById(canvasId).getContext('2d');

    chartInstances[canvasId] = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Word Count',
                data: dataValues,
                backgroundColor: 'rgba(6, 182, 212, 0.7)',
                borderColor: '#06B6D4',
                borderWidth: 1.5,
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { ticks: { color: '#94A3B8' }, grid: { color: 'rgba(255, 255, 255, 0.05)' } },
                y: { ticks: { color: '#94A3B8', precision: 0 }, grid: { color: 'rgba(255, 255, 255, 0.05)' }, beginAtZero: true }
            }
        }
    });
}
