/* ==========================================================================
   SONG LYRICS EXPLORER - ANALYZER & DASHBOARD INTERACTIVE ENGINE
   ========================================================================== */

let currentAnalysisData = null;

document.addEventListener('DOMContentLoaded', () => {
    initTextareaCounters();
    initFormHandlers();
    initTabHandlers();
    initSelectorHandlers();
});

/**
 * Textarea character & line counters
 */
function initTextareaCounters() {
    const textarea = document.getElementById('lyricsText');
    const charCount = document.getElementById('charCount');
    const lineCount = document.getElementById('lineCount');

    if (textarea) {
        textarea.addEventListener('input', () => {
            const text = textarea.value;
            const chars = text.length;
            const lines = text.trim() ? text.split(/\r\n|\r|\n/).length : 0;

            if (charCount) charCount.innerHTML = `<i class="fa-solid fa-keyboard"></i> ${chars} characters`;
            if (lineCount) lineCount.innerHTML = `<i class="fa-solid fa-list-ol"></i> ${lines} lines`;
        });
    }
}

/**
 * Form Submit, Load Sample, Upload, Clear, and New Analysis Handlers
 */
function initFormHandlers() {
    const form = document.getElementById('lyricsForm');
    const btnLoadSample = document.getElementById('btnLoadSample');
    const fileUpload = document.getElementById('fileUpload');
    const btnClear = document.getElementById('btnClear');
    const btnNewAnalysis = document.getElementById('btnNewAnalysis');

    // Load Sample Lyrics
    if (btnLoadSample) {
        btnLoadSample.addEventListener('click', async () => {
            clearAlert();
            try {
                const res = await fetch('/sample-lyrics');
                const data = await res.json();
                if (data.success) {
                    document.getElementById('songTitle').value = data.title;
                    document.getElementById('artistName').value = data.artist;
                    const lyricsArea = document.getElementById('lyricsText');
                    lyricsArea.value = data.lyrics;
                    lyricsArea.dispatchEvent(new Event('input'));
                }
            } catch (err) {
                showAlert("Failed to load sample lyrics.");
            }
        });
    }

    // Handle .txt File Upload
    if (fileUpload) {
        fileUpload.addEventListener('change', async (e) => {
            clearAlert();
            const file = e.target.files[0];
            if (!file) return;

            if (!file.name.endsWith('.txt')) {
                showAlert("Please select a valid .txt lyrics file.");
                return;
            }

            const formData = new FormData();
            formData.append('file', file);

            try {
                const res = await fetch('/upload', {
                    method: 'POST',
                    body: formData
                });
                const data = await res.json();
                if (data.success) {
                    const lyricsArea = document.getElementById('lyricsText');
                    lyricsArea.value = data.lyrics;
                    lyricsArea.dispatchEvent(new Event('input'));
                    
                    // Set auto title if empty
                    const titleInput = document.getElementById('songTitle');
                    if (!titleInput.value) {
                        titleInput.value = file.name.replace('.txt', '').replace(/_/g, ' ');
                    }
                } else {
                    showAlert(data.error || "File upload failed.");
                }
            } catch (err) {
                showAlert("Error uploading text file.");
            }
        });
    }

    // Clear Form
    if (btnClear) {
        btnClear.addEventListener('click', () => {
            clearAlert();
            document.getElementById('songTitle').value = '';
            document.getElementById('artistName').value = '';
            const textarea = document.getElementById('lyricsText');
            textarea.value = '';
            textarea.dispatchEvent(new Event('input'));
        });
    }

    // Form Submission -> Run NLP Analysis
    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            clearAlert();

            const title = document.getElementById('songTitle').value.trim();
            const artist = document.getElementById('artistName').value.trim();
            const lyrics = document.getElementById('lyricsText').value.trim();

            if (!lyrics) {
                showAlert("Please enter or upload song lyrics before analyzing.");
                return;
            }

            // Show Loading Animation Overlay
            showLoading(true, "Tokenizing text & executing NLP pipeline...");

            try {
                const response = await fetch('/analyze', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ title, artist, lyrics })
                });

                const result = await response.json();
                showLoading(false);

                if (response.ok && result.success) {
                    currentAnalysisData = result;
                    try {
                        populateDashboard(result);
                        switchToDashboardView();
                    } catch (renderErr) {
                        console.error("Dashboard render error:", renderErr);
                        showAlert(`Dashboard rendering error: ${renderErr.message}`);
                    }
                } else {
                    showAlert(result.error || "NLP Analysis failed. Please check your text input.");
                }

            } catch (err) {
                console.error("Fetch/Analysis error:", err);
                showLoading(false);
                showAlert(`Server communication error: ${err.message || 'Please check your connection and try again.'}`);
            }

        });
    }

    // New Analysis Button
    if (btnNewAnalysis) {
        btnNewAnalysis.addEventListener('click', () => {
            document.getElementById('dashboardSection').classList.add('hidden');
            document.getElementById('inputSection').classList.remove('hidden');
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }
}

/**
 * Show / Hide Loading Overlay
 */
function showLoading(show, text = "") {
    const overlay = document.getElementById('loadingOverlay');
    const statusText = document.getElementById('loadingStatusText');
    if (overlay) {
        if (show) {
            if (statusText && text) statusText.innerText = text;
            overlay.classList.remove('hidden');
        } else {
            overlay.classList.add('hidden');
        }
    }
}

/**
 * Switch from Input Form to Dashboard View
 */
function switchToDashboardView() {
    document.getElementById('inputSection').classList.add('hidden');
    document.getElementById('dashboardSection').classList.remove('hidden');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

/**
 * Dashboard Tabs Handler
 */
function initTabHandlers() {
    const tabs = document.querySelectorAll('.dash-tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));

            tab.classList.add('active');
            const paneId = tab.getAttribute('data-tab');
            const targetPane = document.getElementById(paneId);
            if (targetPane) targetPane.classList.add('active');
        });
    });
}

/**
 * Selectors for Top Frequencies & N-Grams
 */
function initSelectorHandlers() {
    const freqSelect = document.getElementById('freqTopSelect');
    if (freqSelect) {
        freqSelect.addEventListener('change', (e) => {
            if (!currentAnalysisData) return;
            const topN = parseInt(e.target.value);
            const freqList = currentAnalysisData.frequency[`top_${topN}`] || currentAnalysisData.frequency.top_10;
            renderWordFreqChart(
                'wordFreqChart',
                freqList.map(item => item.word),
                freqList.map(item => item.frequency)
            );
        });
    }

    const btnBigrams = document.getElementById('btnBigrams');
    const btnTrigrams = document.getElementById('btnTrigrams');
    if (btnBigrams && btnTrigrams) {
        btnBigrams.addEventListener('click', () => {
            btnBigrams.classList.add('active');
            btnTrigrams.classList.remove('active');
            if (currentAnalysisData) renderPhrases(currentAnalysisData.phrases.bigrams);
        });
        btnTrigrams.addEventListener('click', () => {
            btnTrigrams.classList.add('active');
            btnBigrams.classList.remove('active');
            if (currentAnalysisData) renderPhrases(currentAnalysisData.phrases.trigrams);
        });
    }
}

/**
 * Populates all Dashboard elements with backend NLP results
 */
function populateDashboard(data) {
    // Song Metadata Header
    document.getElementById('dashTitle').innerText = data.song.title;
    document.getElementById('dashArtist').innerText = `by ${data.song.artist}`;

    // Statistics Cards
    document.getElementById('statTotalWords').innerText = data.statistics.total_words;
    document.getElementById('statUniqueWords').innerText = data.statistics.unique_words;
    document.getElementById('statTTR').innerText = `${data.statistics.vocabulary_richness}%`;
    document.getElementById('statTotalLines').innerText = data.statistics.total_lines;
    document.getElementById('statAvgWordLen').innerText = data.statistics.avg_word_length;
    document.getElementById('statSentences').innerText = data.statistics.total_sentences;
    document.getElementById('statCharacters').innerText = data.statistics.total_characters;
    document.getElementById('statParagraphs').innerText = data.statistics.total_paragraphs;

    // Overview Highlights
    document.getElementById('overviewSentimentEmoji').innerText = data.sentiment.emoji;
    document.getElementById('overviewSentimentClass').innerText = data.sentiment.classification;
    document.getElementById('overviewSentimentText').innerText = data.sentiment.explanation;

    document.getElementById('overviewEmotionEmoji').innerText = data.emotion.dominant_emoji;
    document.getElementById('overviewEmotionName').innerText = data.emotion.dominant_emotion;
    document.getElementById('overviewEmotionScore').innerText = `Share: ${data.emotion.dominant_percentage}%`;
    document.getElementById('dashDominantEmotionTag').innerText = `${data.emotion.dominant_emotion} ${data.emotion.dominant_emoji}`;

    // Render Word Frequency Chart
    const top10 = data.frequency.top_10;
    renderWordFreqChart('wordFreqChart', top10.map(i => i.word), top10.map(i => i.frequency));

    // Word Cloud Image
    const wcImg = document.getElementById('wordcloudImg');
    const wcBtn = document.getElementById('btnDownloadWordcloud');
    if (wcImg && data.wordcloud) {
        wcImg.src = data.wordcloud.base64;
        if (wcBtn) {
            wcBtn.href = `/download/wordcloud/${data.wordcloud.filename}`;
        }
    }

    // Repeated Words Table
    const tbody = document.getElementById('repeatedWordsTableBody');
    tbody.innerHTML = '';
    if (data.frequency.repeated_words.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-muted text-center">No words repeated more than once.</td></tr>';
    } else {
        data.frequency.repeated_words.forEach((item, idx) => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><strong>#${idx + 1}</strong></td>
                <td><span class="token-pill">${item.word}</span></td>
                <td>${item.frequency}</td>
                <td>${item.percentage}%</td>
            `;
            tbody.appendChild(tr);
        });
    }

    // Sentiment Chart
    renderSentimentChart(
        'sentimentChart',
        data.sentiment.positive_score,
        data.sentiment.negative_score,
        data.sentiment.neutral_score
    );
    document.getElementById('sentCompoundVal').innerText = data.sentiment.compound_score;
    document.getElementById('sentSubjectivityVal').innerText = data.sentiment.subjectivity;

    // Emotion Chart
    const emotionLabels = Object.keys(data.emotion.percentages);
    const emotionValues = Object.values(data.emotion.percentages);
    renderEmotionChart('emotionChart', emotionLabels, emotionValues);

    // Phrase Chart (Default Bigrams)
    renderPhrases(data.phrases.bigrams);

    // POS Tagging Chart
    renderPosChart('posChart', data.frequency.pos_percentages);

    // Word Length Distribution Chart
    renderWordLengthChart(
        'wordLengthChart',
        data.word_length.labels,
        data.word_length.values
    );

    // Rhyme Groups Grid
    const rhymeContainer = document.getElementById('rhymeGroupsContainer');
    const rhymeBadge = document.getElementById('rhymeCountBadge');
    rhymeContainer.innerHTML = '';
    if (rhymeBadge) rhymeBadge.innerText = `${data.rhyme.total_groups_count} Groups Detected`;

    if (data.rhyme.rhyme_groups.length === 0) {
        rhymeContainer.innerHTML = '<p class="text-muted">No distinct rhyming clusters identified.</p>';
    } else {
        data.rhyme.rhyme_groups.forEach(group => {
            const card = document.createElement('div');
            card.className = 'rhyme-group-card';
            const pills = group.words.map(w => `<span class="rhyme-pill">${w}</span>`).join('');
            card.innerHTML = `
                <div class="rhyme-group-title">
                    <span>${group.group_name}</span>
                    <small>/${group.phonetic_tail}/</small>
                </div>
                <div class="rhyme-pills">${pills}</div>
            `;
            rhymeContainer.appendChild(card);
        });
    }

    // Structure Metrics Details
    const structBox = document.getElementById('structureDetails');
    structBox.innerHTML = `
        <div class="structure-metric-row"><span>Total Lines</span><strong>${data.structure.lines_count}</strong></div>
        <div class="structure-metric-row"><span>Total Paragraphs / Stanzas</span><strong>${data.structure.paragraphs_count}</strong></div>
        <div class="structure-metric-row"><span>Avg Words Per Line</span><strong>${data.structure.avg_words_per_line}</strong></div>
        <div class="structure-metric-row"><span>Explicit Section Tags Detected</span><strong>${data.structure.has_explicit_markers ? 'Yes' : 'None Detected'}</strong></div>
    `;
    if (data.structure.has_explicit_markers && data.structure.sections.length > 0) {
        const tagHTML = data.structure.sections.map(s => `<span class="badge-tag">${s}</span>`).join('');
        structBox.innerHTML += `<div class="mt-4"><h5>Detected Song Sections:</h5><div class="section-tag-list">${tagHTML}</div></div>`;
    }

    // Preprocessing Inspector
    document.getElementById('preprocOriginal').innerText = data.song.lyrics;
    document.getElementById('preprocCleaned').innerText = data.preprocessing.cleaned_text;
    
    const tokensDiv = document.getElementById('preprocTokens');
    tokensDiv.innerHTML = data.preprocessing.sample_tokens.map(t => `<span class="token-pill">${t}</span>`).join('');
    
    const lemmasDiv = document.getElementById('preprocLemmas');
    lemmasDiv.innerHTML = data.preprocessing.sample_lemmas.map(l => `<span class="token-pill">${l}</span>`).join('');

    // Configure Export Download Links
    const sid = data.session_id;
    document.getElementById('exportJsonBtn').href = `/download/export/json/${sid}`;
    document.getElementById('exportCsvBtn').href = `/download/export/csv/${sid}`;
    document.getElementById('exportPdfBtn').href = `/download/export/pdf/${sid}`;
}

/**
 * Helper to render Bigrams / Trigrams in phrasesChart
 */
function renderPhrases(phraseList) {
    if (!phraseList || phraseList.length === 0) {
        renderPhrasesChart('phrasesChart', ['No Phrases Detected'], [0]);
    } else {
        renderPhrasesChart(
            'phrasesChart',
            phraseList.map(p => p.phrase),
            phraseList.map(p => p.frequency)
        );
    }
}
